from typing import Final


# Should be all-lower for is_called_as_ruyi to work
RUYI_ENTRYPOINT_NAME: Final = "ruyi"
